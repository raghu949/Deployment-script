package com.proj.demoproj;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoprojApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoprojApplication.class, args);
	}

}
